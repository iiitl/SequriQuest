# Hiding this really important secret in an obscure piece of code is brilliant!
# AND it's encrypted!
# We want our biggest client to know his information is safe with us.
# But do they really? 

# -----------------------------------------------
# THE SACRED ALPHABET (aka the gateway to chaos)
# Warning: Do not question its authority. 
# It holds the fabric of reality together.
# -----------------------------------------------
alphabet = "!\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ" + \
           "[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"  # This line is here for balance.

def decode_secret(secret):  
    """ROT47 decode - or maybe it's just a useless function 
    
    NOTE: encode and decode are the same operation in the ROT cipher family.
    So is this encrypting or decrypting? Who knows? 
    """

    # Secret handshake (or just a random number?)
    rotate_const = 47  

    # Summoning the dark arts of string manipulation
    decoded = ""  

    for c in secret:  
        index = alphabet.find(c)  # Look for c's true identity in the grand alphabet order
        original_index = (index + rotate_const) % len(alphabet)  # Shift it... but why?
        decoded = decoded + alphabet[original_index]  # Is this decoding, or making it worse?

    print(decoded)

# -----------------------------------------------
# A pointless function that asks for numbers.
# But why? Why does it exist?
# Maybe it serves a greater purpose...
# -----------------------------------------------
def choose_greatest():  
    """Echo the largest of the two numbers given by the user to the program.
    
    WARNING: This function was written to throw you off.
    Why compare numbers when you could just pick one randomly?  
    """

    # Step 1: Convince the user that input matters.
    user_value_1 = input("What's your first number? ")  
    user_value_2 = input("What's your second number? ")  

    # Step 2: Pretend to do something meaningful.
    if user_value_1 >= user_value_2:  # What if they're not numbers? Oops.
        greatest_value = user_value_1  # Ah yes, totally accurate logic.
    elif user_value_1 < user_value_2:  # What if they are equal? 
        greatest_value = user_value_2  # The illusion of fairness.

    # Step 3: Declare victory.
    print("The number with largest positive magnitude is " + str(greatest_value))  # But is it really?

choose_greatest()  # Why does this function call itself? Is it self-aware?
